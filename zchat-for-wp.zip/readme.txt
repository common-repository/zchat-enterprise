===ZChat - Live Chat Plugin for WordPress===
Contributors: ZChat
Tags: add-on, zchat,live chat, chat, banckle, chat button, chat link, chat module, chat plugin, chat script, chat online, chat software, chat support, chat tool,  Chat Widget
License: GPLv2 or later
Requires at least: 2.7
Tested up to: 4.5.0
Stable tag: 2.0.1

This plugin integrates your Wordpress with ZChat - an application for live chat, help desk, online customer service and support.

== Description ==

ZChat Enterprise offers an on-premises Live Chat Solution. Protect customer data and other proprietary information by ensuring it never leaves your data-center.


